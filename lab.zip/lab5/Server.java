import org.omg.CORBA.*;
import HelloWorld.HelloWorldHelper;
public class Server {
 public static void main(String[] args) {
 try {
 ORB orb = ORB.init(args, null);
 HelloWorldImpl helloWorld = new HelloWorldImpl();
 // Register the HelloWorld object with the ORB
 orb.connect(helloWorld);
 NamingContextExt ncRef =
NamingContextExtHelper.narrow(orb.resolve_initial_references("NameService"));
 NameComponent path[] = ncRef.to_name("HelloWorld");
 ncRef.rebind(path, helloWorld);
 System.out.println("Server is ready and waiting for client requests...");
 orb.run();
 } catch (Exception e) {
 e.printStackTrace();
 }
 }
}