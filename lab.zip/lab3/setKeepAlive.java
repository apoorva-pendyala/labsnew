import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
public class ServerSocketExample {
 public static void main(String[] args) {
 try {
 ServerSocket serverSocket = new ServerSocket(8080);

 // Enable SO_KEEPALIVE
 serverSocket.setKeepAlive(true);

 System.out.println("Server is running. Waiting for a client to connect...");

 Socket clientSocket = serverSocket.accept();

 // Test SO_KEEPALIVE
 System.out.println("SO_KEEPALIVE enabled: " + clientSocket.getKeepAlive());

 // Close the sockets
 clientSocket.close();
 serverSocket.close();
 } catch (IOException e) {
 e.printStackTrace();
 }
 }
}
//SO_KEEPALIVE is a socket option that allows the operating system to automatically send keepalive packets on an idle 
//TCP connection to check if the other end is still responsive.