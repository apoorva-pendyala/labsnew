import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
public class ServerSocketOptionsTest {
 public static void main(String[] args) {
 int port = 8080;
 try {
 // Create a server socket
 ServerSocket serverSocket = new ServerSocket(port);
 // Set SO_KEEPALIVE option (1 enables, 0 disables)
 serverSocket.setKeepAlive(true);
 // Set SO_LINGER option (Linger on close with a timeout of 30 seconds)
 serverSocket.setSoLinger(true, 30);
 // Set SO_SNDBUF option (send buffer size)
//  serverSocket.setSendBufferSize(8192);
//  // Set SO_RCVBUF option (receive buffer size)
//  serverSocket.setReceiveBufferSize(8192);
//  // Set TCP_NODELAY option (disable Nagle's algorithm, true enables, false disables)
 serverSocket.setTcpNoDelay(true);
 System.out.println("Server is listening on port " + port);
 while (true) {
 // Accept incoming connections
 Socket clientSocket = serverSocket.accept();
 System.out.println("Accepted connection from " + clientSocket.getInetAddress());
 // You can perform any necessary server-side operations here
 // Close the client socket
 clientSocket.close();
 }
 } catch (SocketException e) {
 e.printStackTrace();
 } catch (IOException e) {
 e.printStackTrace();
 }
 }
}