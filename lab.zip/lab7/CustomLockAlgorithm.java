import java.util.concurrent.atomic.AtomicInteger;

public class CustomLockAlgorithm {
    private AtomicInteger[] tickets;
    private AtomicInteger[] entering;
    private int numThreads;

    public CustomLockAlgorithm(int numThreads) {
        this.numThreads = numThreads;
        tickets = new AtomicInteger[numThreads];
        entering = new AtomicInteger[numThreads];
        for (int i = 0; i < numThreads; i++) {
            tickets[i] = new AtomicInteger(0);
            entering[i] = new AtomicInteger(0);
        }
    }

    public void lock(int threadId) {
        entering[threadId].set(1);
        int max = 0;
        for (int i = 0; i < numThreads; i++) {
            int ticket = tickets[i].get();
            max = Math.max(max, ticket);
        }
        tickets[threadId].set(max + 1);
        entering[threadId].set(0);

        for (int i = 0; i < numThreads; i++) {
            if (i != threadId) {
                while (entering[i].get() == 1) {
                    // Wait for the other thread to choose its ticket
                }

                while (tickets[i].get() != 0 && (tickets[threadId].get() > tickets[i].get() || (tickets[threadId].get() == tickets[i].get() && threadId > i))) {
                    // Wait for the other thread to finish
                }
            }
        }
    }

    public void unlock(int threadId) {
        tickets[threadId].set(0);
    }

    public static void main(String[] args) {
        int numThreads = 6;
        CustomLockAlgorithm customLock = new CustomLockAlgorithm(numThreads);

        Runnable runnable = () -> {
            int threadId = Integer.parseInt(Thread.currentThread().getName());
            customLock.lock(threadId);
            // Critical section
            System.out.println("Thread " + threadId + " is in the critical section.");
            customLock.unlock(threadId);
        };

        for (int i = 0; i < numThreads; i++) {
            Thread thread = new Thread(runnable, Integer.toString(i));
            thread.start();
        }
    }
}


// SE20UCSE245; APOORVA PENDYALA